#ifndef _I_MC_MEDIA_CONTROL_H_
#define _I_MC_MEDIA_CONTROL_H_

#include "IMcControl.h"

class IMcMediaControl : public IMcControl {
public:
	virtual ~IMcMediaControl() = default;

};

#endif // !_I_MC_MEDIA_CONTROL_H_

